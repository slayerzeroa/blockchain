import React from 'react'

function NavBar() {
  return (
    <div>NavBar</div>
  )
}

export default NavBar